-- ENGLISH 9: ADD ONLY. Run once in Supabase SQL Editor after a database backup.
-- This function re-validates the real student code/password through the existing
-- public.student_login RPC. It does NOT allow the client to choose a different student.
-- Submitted marks are browser-reported and are deliberately NOT verified grades.
CREATE FUNCTION public.student_submit_result(
  p_student_code text,
  p_password text,
  p_student_id uuid,
  p_unit integer,
  p_skill text,
  p_exercise text,
  p_score numeric,
  p_correct integer,
  p_total integer,
  p_passed boolean,
  p_attempt integer,
  p_xp integer,
  p_client_attempt_id text
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_login jsonb;
  v_verified_student_id uuid;
  v_submission_id uuid;
  v_existing_id uuid;
BEGIN
  IF p_student_code IS NULL OR length(trim(p_student_code)) = 0 OR
     p_password IS NULL OR length(p_password) = 0 THEN
    RAISE EXCEPTION 'Invalid student credentials';
  END IF;
  IF p_unit NOT BETWEEN 1 AND 12 OR
     p_skill NOT IN ('vocabulary','grammar','listening','practice','pronunciation','challenge') OR
     p_total NOT BETWEEN 1 AND 1000 OR p_correct NOT BETWEEN 0 AND p_total OR
     p_score NOT BETWEEN 0 AND 100 OR
     p_attempt NOT BETWEEN 1 AND 100000 OR p_xp NOT BETWEEN 0 AND 1000 OR
     length(coalesce(p_exercise,'')) NOT BETWEEN 1 AND 240 THEN
    RAISE EXCEPTION 'Invalid exercise result';
  END IF;

  -- Existing authentication source of truth. A row is returned only when
  -- the supplied code and password are correct.
  SELECT to_jsonb(login_row) INTO v_login
    FROM public.student_login(p_student_code, p_password) AS login_row LIMIT 1;
  IF v_login ? 'student_login' THEN
    v_login := v_login->'student_login';
  END IF;
  IF v_login IS NULL OR NOT (v_login ? 'student_id') THEN
    RAISE EXCEPTION 'Student authentication failed';
  END IF;

  SELECT s.id INTO v_verified_student_id
    FROM public.students s
    WHERE s.id = p_student_id AND s.id::text = (v_login->>'student_id')
      AND s.student_code = trim(p_student_code) AND s.active IS DISTINCT FROM false;
  IF v_verified_student_id IS NULL THEN
    RAISE EXCEPTION 'Student is not authorized for this submission';
  END IF;

  -- Repeated clicks or retries return the existing submission, not a duplicate.
  IF p_client_attempt_id IS NOT NULL AND length(p_client_attempt_id) BETWEEN 1 AND 120 THEN
    SELECT x.id INTO v_existing_id FROM public.submissions x
      WHERE x.student_id = v_verified_student_id
      AND x.answers->>'clientAttemptId' = p_client_attempt_id LIMIT 1;
    IF v_existing_id IS NOT NULL THEN RETURN v_existing_id; END IF;
  END IF;

  INSERT INTO public.submissions (
    student_id, activity_id, activity_type, unit_number, answers, grading_status
  ) VALUES (
    v_verified_student_id,
    left(lower(p_skill) || '-u' || p_unit || '-' || p_exercise, 240),
    lower(p_skill), p_unit,
    jsonb_build_object(
      'exercise', p_exercise, 'correct', p_correct, 'total', p_total,
      'passed', p_passed, 'attempt', p_attempt, 'xpEarned', p_xp,
      'clientReportedScore', p_score, 'source', 'student_submit_result',
      'clientAttemptId', p_client_attempt_id
    ), 'pending'
  ) RETURNING id INTO v_submission_id;
  RETURN v_submission_id;
END;
$$;

REVOKE ALL ON FUNCTION public.student_submit_result(text,text,uuid,integer,text,text,numeric,integer,integer,boolean,integer,integer,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.student_submit_result(text,text,uuid,integer,text,text,numeric,integer,integer,boolean,integer,integer,text) TO anon, authenticated;
-- Ask PostgREST to refresh the newly created RPC signature.
NOTIFY pgrst, 'reload schema';
